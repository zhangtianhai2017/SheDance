SheDance dance1 FBX (skinned SMPL body) — for UE 5.6 import + IK retargeting

dance1.fbx        animation, 683 frames @ 30fps, baked to bones; skinned SMPL body mesh.
dance1_tpose.fbx  rest reference (SMPL zero pose = star/A-pose, NOT a horizontal T-pose);
                  use this as the source retarget pose.

Skeleton : 22 SMPL body bones (idx 0-21), single root 'pelvis', SMPL/SMPL-X body names.
Mesh     : 6890 verts / 13776 faces. SMPL-H skin weights, finger weights folded into wrists
           -> 22 vertex groups. Armature modifier. betas[-2,2] female body. No textures.
Coords   : Z-up, X-forward, meters (apply x100 on import if UE wants cm).
Floor    : FLOOR-ALIGNED. Lowest skinned-mesh contact over the whole clip -> Z=0 (single global
           offset, relative vertical motion preserved: planted frames touch floor, jumps go airborne).
           frame0 pelvis at origin (X=Y=0). Pelvis natural height ~0.89m.
Bone rest: ALL bone rest rotations = Rx(+90deg) (so standard SMPL weights deform correctly).
           Bones therefore look like short +Z stubs and do not visually connect — this is correct;
           LBS deformation and per-bone world rotation (= joint_world_rot) are both correct.
Built    : headless Blender (bpy 4.2) from our joints_world.
Verified : bone head-pos 0.0005mm vs joints_world; skin-deform 0.55mm vs hand-computed SMPL-LBS.

Full notes: comms/msgs/*from-SHEDANCE*skinned* ; data contract: ../README.md (SheDance_DATA_CONTRACT).

# SheDance 实例数据 —— dance1(先读这个)

一段**真实舞蹈**(dance1)的完整输出实例,用来试你们的消费/转换。
- **683 帧 @ 30fps ≈ 22.8 秒**;身体 = 女性 betas −2,2。
- 本版已修:**体态**(无塌腰/腹凸)、**脚锁定**(支撑相 0 滑)、**手关节**(`left_hand/right_hand` 各 ~10cm;此前 `right_hand` 离腕 1.49m 的 bug 已修)。
- **格式规范见同目录 `README.md`(= 锁定的《数据格式契约 v1》)**;本文只讲这份样例怎么用。

## 最快验证(按此顺序)
1. **`data/dance1_joints_world.npz`** ←先试。`np.load` → `joints_world (683,24,3)` 世界坐标(米,Z-up)+ `joint_names`(★权威,照它迭代)+ `parents` + `fps`。不用装任何库。
2. `data/dance1_poses.npz` —— SMPL-H 旋转 `poses(683,156)` + `trans`;手指槽 `[:,66:156]` 当前为 0(`np.any(...!=0)`=False)。
3. `data/dance1_qpos.npz` —— `qpos(683,89)` + `frequency` + **`has_fingers=False` / `dof=89`**(本版无手指)。`qpos[:,0:7]`=根(xyz+四元数wxyz)。
4. `data/dance1_activation.sto` —— 肌肉激活(227 列固定,按其 `time` 列对齐,起点 ~0.1s)。
5. `data/dance1_ik.mot` —— OpenSim IK(49 列,度)。

## 帧对齐
`poses / joints_world / qpos / ik.mot` 都是 **683 帧 @30fps,按行号对齐**;`.sto` 按其 `time` 列(~671 帧,SO 窗口)。全部世界系 Z-up、米。

## 对照
`preview/dance1_skin.mp4` —— 这段动作渲染出来的样子(女性身材、体态正常、脚不滑)。

跑通/卡住都发我。格式细节一律以 `README.md`(契约 v1)为准。

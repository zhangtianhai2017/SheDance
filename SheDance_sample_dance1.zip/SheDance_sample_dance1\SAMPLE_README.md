# SheDance 实例数据 —— dance1(先读这个)

一段**真实舞蹈**(dance1)的完整输出实例,用来试你的消费/转换**跑不跑得通**。
- **683 帧 @ 30fps ≈ 22.8 秒**,locked 版(已做脚锁定,脚不滑)。
- 数据结构的完整说明见同目录 `README.md` + `ref/`;本文只讲**这份样例怎么用**。

---

## 最快验证(建议按这个顺序试)

1. **`data/dance1_joints_world.npz`** ← **最省事,先试这个**。`np.load` 直接拿到 24 个关节的**世界坐标**,不用装任何库、不用 smplx:
   ```python
   import numpy as np
   z = np.load("data/dance1_joints_world.npz", allow_pickle=True)
   J     = z["joints_world"]   # (683, 24, 3) 世界坐标,米,Z 轴朝上
   names = z["joint_names"]    # 24 个关节名(pelvis, left_hip, ... head ...)
   par   = z["parents"]        # 父索引(画骨架连线 / 建层级用)
   fps   = float(z["fps"])     # 30.0
   ```
   把这 24 个点逐帧画出来 / 驱动你的骨架,就能直观看出对不对。

2. **`data/dance1_poses.npz`** —— 标准 **SMPL-H** 旋转动作(要用关节旋转驱动时用这个):
   ```python
   z = np.load("data/dance1_poses.npz", allow_pickle=True)
   poses = z["poses"]   # (683,156) 52 关节×3 轴角; [:, :66]=身体24关节, [:,66:]=手指(静止)
   trans = z["trans"]   # (683,3) 根位移,米
   betas = z["betas"]   # (16,) 体型; gender, mocap_framerate 也在里面
   ```
   关节顺序/父子/分段 → `README.md` §3。

3. **`data/dance1_qpos.npz`** —— MyoFullBody 89 自由度(`qpos (683,89)`;`qpos[:,0:7]`=根 xyz+四元数wxyz)。需要解剖级关节(脊柱分段等)时用。顺序见 `ref/myofullbody_layout.txt`。

4. **`data/dance1_activation.sto`** —— 逐肌肉激活(肌肉效果层,选做)。OpenSim 文本,有 `time` 列;**注意它是 SO 时间窗 [0.1, 22.6]s(~671 帧),按它自己的 `time` 列对齐**,别按行号对。列顺序见 `ref/sto_columns.txt`。

5. **`data/dance1_ik.mot`** —— OpenSim IK 广义坐标(角度制,683 帧)。一般驱动用不上,完整起见附上。列见 `ref/mot_columns.txt`。

---

## 帧对齐(重要)

| 文件 | 帧数 | 对齐方式 |
|------|------|---------|
| dance1_poses / joints_world / qpos / ik.mot | **683** @30fps | 直接按行号(第 i 行 = 第 i 帧) |
| dance1_activation.sto | ~671(SO 窗 0.1–22.6s) | **按 `time` 列**对齐,起点 t=0.1s |

全部:世界系 **Z 轴朝上**,米 / 弧度(`.mot` 是度)/ 秒。

## 对照
`preview/dance1_skin.mp4` —— 这段动作渲染出来的样子。你驱动出来的应当跟它一致(动作、朝向)。

## 跑通了 / 没跑通
- 跑通了告诉我,我再按你模块需要的形态调(导成别的字段/CSV/JSON/逐帧等)。
- 卡住了把报错或现象发我,大概率是坐标系(Z-up vs Y-up)、旋转约定(轴角 vs 四元数 vs 欧拉)、或关节顺序对不上——这些 `README.md` 里都写死了,可逐条核。

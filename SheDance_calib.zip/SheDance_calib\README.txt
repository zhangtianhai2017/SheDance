﻿SheDance retargeting CALIBRATION kit -- arm/hand batch (v1, 2026-06-08)

PURPOSE
  Verify the IK Retargeter maps every SheDance bone to the right MetaHuman bone with the correct
  axis and sign, and align the rest pose. SAME skeleton as the dance FBX: 22 SMPL body bones,
  single root 'pelvis', SMPL/SMPL-X names, Rx(+90) bone rest, 6890-vert skinned mesh, Z-up, meters.
  Import calib_arm.fbx with the SAME IK Retargeter you use for dance1.fbx.

HOW TO USE
  Scrub the timeline -- each pose is held static for 1 second (30 frames @ 30fps).
    frame   0-29  (0-1s)  T-pose  (rest baseline; SMPL zero pose, arms ~horizontal)
    frame  30-59  (1-2s)  A-pose  (both arms down 45deg -- matches MetaHuman's default A-pose; use to align rest)
    then each 1s segment rotates ONE joint about ONE local axis by +35deg, everything else neutral.
  On the retargeted MetaHuman the SAME single bone should move the same way each segment.
  If a different bone moves, or the direction is reversed, that bone's mapping/axis is wrong.
  Local X = twist along the limb (small endpoint motion); Y / Z = swing (large).

FILES
  calib_arm.fbx        780 frames @ 30fps (26 poses x 1s)
  calib_timeline.txt   per-segment list (frame range / time -> action)
  calib_manifest.csv   machine-readable: pose, frame_start, frame_end, t_start_s, t_end_s, joint_idx, joint_name, axis, angle_deg, desc
  calib_preview.mp4    skin preview (follow along with the timeline)

THIS BATCH = collar, shoulder, elbow, wrist (L & R). Spine / neck / head + legs to follow.

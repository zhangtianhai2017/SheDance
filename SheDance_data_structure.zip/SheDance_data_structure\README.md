# SheDance 生成数据 —— 完整结构规范

> 给对接模块的开发者:这是 SheDance 离线流程**产出的全部数据的完整结构**。
> 你照这个把我的数据**转成你模块需要的形态**(转换那步你那边做)。本文只讲**数据本身**,不涉及 UE。
>
> 最后更新:2026-06-06 · 一切时间序列第一维 `T` = 帧数 · 典型 30fps

---

## 0. 你最可能要的:驱动人物的「动作」在哪

| 想要 | 用这个 | 形态 |
|------|--------|------|
| **驱动一个人形角色的动作**(首选) | `*_poses.npz` 的 `poses`+`trans` | **SMPL-H 标准人形骨架**:24 个身体关节的旋转(轴角)+ 根位移 |
| 关节的**世界坐标点**(想用位置/IK 驱动) | 由上面 FK 算出(§3.4 给了代码) | 每帧 N 个 3D 点 |
| 肌骨模型的关节角(解剖向) | `*_cache.npz` 的 `qpos` | MyoFullBody 89 自由度 |
| **肌肉发力/鼓起效果** | `*_activation.sto` | 每帧每条肌肉的激活 0–1 |

> 一句话:**驱动角色动作就吃 `poses.npz`(标准 24 关节人形)**;要肌肉效果再叠 `.sto`。其余是中间产物/另一种表示。

---

## 1. 全局约定(所有数据通用)

- **坐标系**:世界系 **Z 轴朝上**,右手系。单位 **米 / 弧度 / 秒**。
- **视频源**(SAM 3D Body)是相机系、**Y 朝下**;我已转成世界系,换算是 `world = [X, Z, -Y]`(你拿到的已经是世界系,这条仅供溯源)。
- **旋转表示**(三种数据三种约定,注意别混):
  - `poses.npz` → **轴角 axis-angle**(每关节 3 个数,模长=转角弧度,方向=转轴);SMPL 规范。
  - `qpos` 的根 → **四元数 `wxyz`**(MuJoCo 约定,w 在前)。
  - `.mot` → **角度(度)**(OpenSim,`inDegrees=yes`)。
- **帧率**:`poses.npz` 存在 `mocap_framerate`,`cache.npz` 存在 `frequency`,典型 `30.0`。
- **落地**:脚最低点贴近地面 z≈0(管线里有碰撞/落地 + 脚锁定处理)。

---

## 2. 产出文件总览(哪步产哪个)

```
视频/AIST → SMPL-H 姿态 ──(retarget)→ MyoFullBody qpos ──(OpenSim IK)→ .mot ──(SO)→ .sto
              │                              │                                          │
         *_poses.npz                    *_cache.npz                            *_activation.sto
        (标准人形动作)               (89-dof 肌骨关节)                       (逐肌肉激活)
              └────────────────── 皮肤/肌肉渲染 → *.mp4(仅预览，非数据)
```

| 文件 | 产出脚本 | 内容 |
|------|---------|------|
| `<dance>_poses.npz` | `source_to_our_poses.py` / `convert_aist.py` | SMPL-H 人形动作(见 §3) |
| `<dance>_cache.npz`、`_refined`、`_locked` | `retarget_smplh.py` → `refine_collision.py` → `footlock.py` | MyoFullBody `qpos`(见 §4) |
| `<dance>_ik.mot` | `add_markers_and_ik.py` | OpenSim IK 广义坐标(见 §6) |
| `<chunk>_StaticOptimization_activation.sto` | `run_so_parallel_dance.sh` | 逐肌肉激活(见 §5) |
| `<dance>_*.mp4` | `render_*.py` | 渲染视频(预览,非结构化) |

---

## 3. ★ 输出① `*_poses.npz` —— SMPL-H 人形动作(驱动首选)

```
poses            (T, 156) float64   # SMPL-H 52 关节 × 3 轴角
trans            (T, 3)   float64   # 根(骨盆)平移,世界系米
betas            (16,)    float64   # 体型 PCA 系数(我们人形 = [0,3,0,...] 偏苗条女)
gender           ()       str       # "female" / "male" / "neutral"
mocap_framerate  ()       float     # 帧率,如 30.0
```

### 3.1 `poses` 的 156 怎么分
52 关节 × 3 = 156,**顺序固定**:
- `poses[:, 0:3]` = **全局朝向**(根旋转,轴角)
- `poses[:, 3:66]` = **21 个身体关节**(索引 1–21,见 §3.3 表)
- `poses[:, 66:156]` = **30 个手指关节**(左手 22–36、右手 37–51;我目前留 MANO 静止,略蜷,值接近 0)

> 只要身体动作 → 取 `poses[:, :66]`(24 关节含全局)即可,手指可忽略。

### 3.2 SMPL-H 52 关节名 + 父子(运动学树)
身体 24 关节父索引(`-1`=根):
```
idx :  0   1   2   3   4   5   6   7   8   9  10  11  12  13  14  15  16  17  18  19  20  21
par : -1   0   0   0   1   2   3   4   5   6   7   8   9   9   9  12  13  14  16  17  18  19
```
名字(0–21):
```
0 pelvis      1 left_hip     2 right_hip    3 spine1
4 left_knee   5 right_knee   6 spine2       7 left_ankle
8 right_ankle 9 spine3       10 left_foot   11 right_foot
12 neck       13 left_collar 14 right_collar 15 head
16 left_shoulder 17 right_shoulder 18 left_elbow 19 right_elbow
20 left_wrist 21 right_wrist
```
手指(22–51,每手 15 = 5 指 × 3 节,顺序 index→middle→pinky→ring→thumb):
```
左手 22..36: left_index1/2/3, left_middle1/2/3, left_pinky1/2/3, left_ring1/2/3, left_thumb1/2/3
右手 37..51: 同上 right_*
父子: 每指的 *1 父 = 手腕(左 20 / 右 21);*2 父 = *1;*3 父 = *2
```

### 3.3 `betas` 与体型
SMPL-H 形状 16 维 PCA;我们固定用 `[0, 3, 0, ..., 0]`(第 2 个分量=3 → 苗条女性身材)。
**同一具身体(同 betas + gender + 同 SMPL-H 模型)才能复现出我看到的网格/骨长**。SMPL-H 模型文件本身受限授权,需自行注册(见末尾)。

### 3.4 由 poses 反求关节世界坐标(若你想用位置/IK 驱动)
标准 SMPL 前向运动学(骨长来自 SMPL-H 模型的 rest 关节;无 blendshape 也够算骨架):
```python
import numpy as np
from scipy.spatial.transform import Rotation as R
PAR = [-1,0,0,0,1,2,3,4,5,6,7,8,9,9,9,12,13,14,16,17,18,19,20,21]
# restJ: (24,3) SMPL-H 模型在 betas 下的 rest 关节位置(由 smplx 取得)
def joints_world(poses_t, trans_t, restJ):
    G=[None]*24; J=np.zeros((24,3))
    for j in range(24):
        Rl=R.from_rotvec(poses_t[3*j:3*j+3]).as_matrix()
        if PAR[j]==-1: G[j]=Rl; J[j]=restJ[j]
        else: G[j]=G[PAR[j]]@Rl; J[j]=J[PAR[j]]+G[PAR[j]]@(restJ[j]-restJ[PAR[j]])
    return J+trans_t   # (24,3) 世界坐标
```
> 需要的话我可以**直接多导一个 `joints_world (T,24,3)` 的 npz**给你,省得你装 smplx。说一声。

---

## 4. 输出② `*_cache.npz` —— MyoFullBody `qpos`(89 自由度肌骨关节)

```
qpos       (T, 89) float64   # MyoFullBody 位形向量
frequency  ()      float     # 帧率,如 30.0
```
- `qpos[0:7]` = 根自由关节 `(x, y, z, quat_w, quat_x, quat_y, quat_z)`(四元数 **wxyz**)。
- `qpos[7:89]` = 其余 82 个关节,**严格按 `ref/myofullbody_layout.txt` 的关节顺序**(腰椎 L1–L5、胸腰、肩带 sternoclavicular/acromioclavicular、肩肘…)。该文件逐行给出 `关节名 : 类型 : qpos 下标`。
- 三个版本同结构,差别只在**根轨迹**(关节角一致):`_cache`(原始重定向)→ `_refined`(碰撞细化)→ `_locked`(脚锁定,消脚滑)。**驱动用 `_locked`**。
- 这是解剖级模型(89 自由度,比游戏 rig 细很多)。驱动普通人形角色一般用 §3 的 SMPL-H 24 关节更顺;`qpos` 适合需要解剖关节(如脊柱分段)时。

> 完整 89(及含手指的 129)关节清单 + 354/416 条肌肉清单 → `ref/myofullbody_layout.txt`。

---

## 5. 输出③ `*_activation.sto` —— 逐肌肉激活(肌肉效果用)

OpenSim `.sto` 文本格式:
```
头部: "Static Optimization" / version=1 / nRows=帧数 / nColumns=227 / inDegrees=no / endheader
之后: 一行列名(time + 226 列),再每帧一行数值
```
- 第 1 列 `time`(秒)。其余 226 列 = 各肌肉/储备/残差作动器。**肌肉激活 ∈ [0,1]**(储备/残差列是力/力矩)。
- 列的**完整顺序**见 `ref/sto_columns.txt`(227 行)。分组:
  - `2–41` 右腿 40 肌(addbrev_r…vasmed_r)
  - `42–81` 左腿 40 肌(_l)
  - `82–95` 右脊柱 LD 14、`96–109` 左脊柱 LD 14
  - 肩臂共享 24(DELT1.. + _l)、右臂 9、左臂 8
  - 其后 `*_actuator` / `rib*act` / `res_*` = 储备 & 残差(不是真肌肉,是补偿项)
- ⚠️ **重要**:`.sto` 的肌肉命名是 **OpenSim 模型**的(`soleus_r`/`glmax1_r`…),**与 MuJoCo MyoFullBody 的 354 条肌肉命名不同**。我渲染时按**肌肉名字**把 .sto 激活映射回 MyoFullBody(实测约 113/354 能对上)。你若要把激活贴到某套肌肉/形变上,需自己定一张名字映射表。

---

## 6. 输出④ `*_ik.mot` —— OpenSim IK 广义坐标

OpenSim `.mot` 文本:`Coordinates` / `inDegrees=yes` / 49 列。
- 第 1 列 `time`,其后 48 个广义坐标:骨盆 6(`pelvis_tilt/list/rotation/tx/ty/tz`)、右腿 7、左腿 7、腰椎/腹 18(`Abs_*`、`L5_S1_*`…`L1_L2_*`,FE/LB/AR=屈伸/侧弯/轴转)、肩臂 10。
- 完整 49 列 → `ref/mot_columns.txt`。
- 这是同一段动作的 **OpenSim 表示**(角度制),与 `qpos` 等价、供 OpenSim 侧消费;驱动 UE 一般不用它。

---

## 7. 输出⑤ 渲染视频 `*.mp4`

仅**预览参考**,非结构化数据:皮肤舞蹈(`*_dance1*.mp4`)、肌肉激活上色(`*_muscle.mp4`)、脚锁定对比(`footlock_compare.mp4`)等。

---

## 8. 怎么读(最小示例)

```python
import numpy as np
z = np.load("dance1_poses.npz", allow_pickle=True)
poses, trans = z["poses"], z["trans"]          # (T,156) 轴角, (T,3) 米
print(poses.shape, trans.shape, z["betas"], str(z["gender"]), float(z["mocap_framerate"]))

c = np.load("ourdance1_locked_cache.npz", allow_pickle=True)
qpos = c["qpos"]                                # (T,89); qpos[:,0:7]=根(xyz+quat wxyz)
```

---

## 9. 附:本目录
```
SheDance_data_structure/
├── README.md                 ← 本规范
└── ref/
    ├── myofullbody_layout.txt  (89/129 关节 + 354/416 肌肉的逐项清单)
    ├── sto_columns.txt         (.sto 的 227 列完整顺序)
    └── mot_columns.txt         (.mot 的 49 列完整顺序)
```

## 10. 受限项(与结构无关,提一句)
SMPL-H / MANO 模型本体(算 §3.4 的 restJ、或渲染皮肤时)是马普所受限授权,需自行注册:https://mano.is.tue.mpg.de/ 。
**但若你只消费我导出的 `poses`/`trans`/`qpos`/`.sto` 数值去做转换,并不需要该模型**——数值本身已在上面 npz 里。
